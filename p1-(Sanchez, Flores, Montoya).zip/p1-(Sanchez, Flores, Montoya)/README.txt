CS 482/502 Database Management Systems I
Project � Part 1

Team Memebers: Fransisco Sanchez, Alejandro Flores, Ne'kko Montoya

Responsibilities:
	Fransisco Sanchez: Implemented the database, and created tables and constraints by writing DDL Statements
	Alejandro Flores: Inserted random records into the implemented tables using DML statements.
	Ne'kko Montoya: Reviewed and checked all work done looking for errors, typos, bugs, or failed constraints.